export const users = async (req, res) => {
  res.json({
    data: "Ryan Zen David Kevin Sara Jane from controller",
  });
};
