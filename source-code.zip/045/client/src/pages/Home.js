import Jumbotron from "../components/cards/Jumbotron";

export default function Home() {
  return (
    <div>
      <Jumbotron title="Hello World" />
    </div>
  );
}
