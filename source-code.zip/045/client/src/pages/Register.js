import Jumbotron from "../components/cards/Jumbotron";

export default function Register() {
  return (
    <div>
      <Jumbotron title="Register" />
    </div>
  );
}
