import Jumbotron from "../components/cards/Jumbotron";

export default function Login() {
  return (
    <div>
      <Jumbotron title="Login" />
    </div>
  );
}
