export default function Login() {
  return (
    <div>
      <h1>This is Login page</h1>
    </div>
  );
}
